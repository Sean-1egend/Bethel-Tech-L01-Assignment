// alert("L01 Assignment");

function stringCounter(sentence){
    var wordCount = sentence.split(" ").length;
    console.log("No. of words: " + wordCount);
    var num = sentence.length;
    console.log("No. of characters: " + num);
}



// TEST CASE 1
let sentence1 = "The largest living thing on earth is a giant sequoia named General Sherman";
stringCounter(sentence1);

// TEST CASE 2
let sentence2 = "A sunset on Mars is blue";
stringCounter(sentence2);
